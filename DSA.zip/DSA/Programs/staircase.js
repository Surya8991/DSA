function stairCase(n){
    for(let i=1;i<=n;i++){
        console.log(" ".repeat(n-i)+"#".repeat(i)+"#".repeat(i)+" ".repeat(n-i))
    }
}
console.log(stairCase(10))