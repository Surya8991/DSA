function vowelsAndConsonants(s){
    let vowels=(/[aeiou]/gi)
    let nonVowels=(/[^aeiou]/gi)
    let matchVowels=s.match(vowels)
    let matchNonVowels=s.match(nonVowels)
    for (let i = 0; i < matchVowels.length; i++) {
        console.log(matchVowels[i])
    }
    for (let i = 0; i < matchNonVowels.length; i++) {
        console.log(matchNonVowels[i])
    }
}
console.log(vowelsAndConsonants("JavaScriptLoops"))