var btn=document.getElementById("btn")
btn.innerHTML="0"
var count=0
btn.addEventListener('click',function(){
    count++
    btn.innerHTML=count
})