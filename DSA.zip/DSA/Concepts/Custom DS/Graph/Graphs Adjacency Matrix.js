let matrix = [
    [0, 1, 0],
    [1, 0, 1],
    [0, 1, 0]]
  console.log(matrix[0][1])