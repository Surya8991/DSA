class Graph {
    constructor() {
        this.adjacencyList = {}
    }
    //Adding Vertex
    addVertex(vertex) {
        if (!this.adjacencyList[vertex]) {
            this.adjacencyList[vertex] = new Set()
        }
    }
    //Adding Edge
    addEdge(vertex1, vertex2) {
        if (!this.adjacencyList[vertex1]) {
            this.addVertex(vertex1)
        }
        if (!this.adjacencyList[vertex2]) {
            this.addVertex(vertex2)
        }
        this.adjacencyList[vertex1].add(vertex2)
        this.adjacencyList[vertex2].add(vertex1)
    }
    //Display
    display() {
        for (let vertex in this.adjacencyList) {
            console.log(vertex + '->' + [...this.adjacencyList[vertex]])
        }
    }
    //Has Edge to check the connection between Nodes(vertex)
    hasEdge(vertex1, vertex2) {
        return (
            this.adjacencyList[vertex1].has(vertex2) &&
            this.adjacencyList[vertex2].has(vertex1)

        )
    }
    //removeEdge
    removeEdge(vertex1, vertex2) {
        this.adjacencyList[vertex1].delete(vertex2)
        this.adjacencyList[vertex2].delete(vertex1)
    }
    //Remove Vertex
    removeVertex(vertex) {
        if (!this.adjacencyList[vertex]) {
            return
        }
        for (let adjacencyVertex of this.adjacencyList[vertex]) {
            this.removeEdge(vertex, adjacencyVertex)
        }
        delete this.adjacencyList[vertex]
    }
}

//Implemnetation
const graph = new Graph()
graph.addVertex('A')
graph.addVertex('B')
graph.addVertex('C')
graph.addEdge('A', 'B')
graph.addEdge('C', 'B')
graph.display()
console.log(" \n Using hasEdge Method \n ",graph.hasEdge('A','B'))
graph.removeVertex('B')
console.log("\n After Deleting B Vertex")
graph.display()