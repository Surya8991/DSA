let adjacencyList = {
    "A": ["B"],
    "B": ['A', 'C'],
    'C': ['B']
  }
  console.log(adjacencyList['B'])