class Stack{
    constructor(){
      this.items=[];
    }
    push(element){
      this.items.push(element)
    }
    pop()
    {
      return this.items.pop()
    }
    peek(){
      return this.items[this.items.length-1];
    }
    isEmpty(){
      return this.items.length===0;
    }
    size()
    {
      return this.items.length;
    }
    print(){
      console.log(this.items.toString())
    }
  }
  
  const stack = new Stack();
  console.log("\n Adding in stack")
  stack.push(2);
  stack.push(12);
  stack.push(45)
  stack.push(23);
  console.log(stack)
  
  console.log("\n Removing an element in stack")
  stack.pop()
  console.log(stack)
  
  console.log("\n Size of element in stack")
  console.log(stack.size())
  
  console.log("\n Using peek element in stack")
  console.log(stack.peek())
  
  console.log("\n Printing all element in stack")
  console.log(stack.print())