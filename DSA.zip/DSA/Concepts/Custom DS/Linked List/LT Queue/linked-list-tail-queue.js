const LinkedList = require("./linked-list-tail");

class LinkedListQueue {
  constructor() {
    this.list = new LinkedList()
  }
  enqueue(value) {
    this.list.append(value)
  }
  dequeue() {
    this.list.removeFromFront()
  }
  isEmpty() {
    return this.list.isEmpty()
  }
  peek() {
    return this.list.head.value
  }
  getSize() {
    return this.list.getSize()
  }
  print() {
    return this.list.print()
  }
}

const q = new LinkedListQueue()
console.log(q.isEmpty())
q.enqueue(2)
q.enqueue(12)
q.enqueue(22)
q.enqueue(23)
q.enqueue(24)
console.log(q.print())
q.dequeue()
console.log(q.print())
console.log(q.getSize())
console.log(q.peek())