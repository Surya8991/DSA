//Create a node
class Node {
    constructor(value) {
      this.value = value;
      this.next = null
    }
  }
  
  //Creating an Linkded list
  
  //Linked list class
  
  class linkedList {
    constructor() {
      this.head = null
      this.size = 0
    }
    isEmpty() {
      return this.size === 0
    }
    getSize() {
      return this.size
    }
    prepend(value) {
      const node = new Node(value)
      if (this.isEmpty()) {
        this.head = node
      } else {
        node.next = this.head
        this.head = node
      }
      this.size++
    }
    append(value) {
      const node = new Node(value);
      if (this.isEmpty()) {
        this.head = node;
      } else {
        let curr = this.head;
        while (curr.next) {
          curr = curr.next;
        }
        curr.next = node;
      }
      this.size++;
    }
  
    //Insert at an Index
    insert(value, index) {
      if (index < 0 || index > this.size) {
        return undefined
      }
      if (index === 0) {
        this.prepend(value)
      }
      else {
        let prev = this.head
        const node = new Node(value)
        for (let i = 0; i < index - 1; i++) {
          prev = prev.next
        }
        node.next = prev.next
        prev.next = node
        this.size++
      }
    }
  
    //Remove from index 
    remove(index) {
      if (index < 0 || index > this.size) {
        return undefined
      }
      let removeNode
      if (index === 0) {
        removeNode = this.head
        this.head = this.head.next
      }
      else {
        let prev = this.head
        for (let i = 0; i < index - 1; i++) {
          prev = prev.next
        }
        removeNode = prev.next
        prev.next = removeNode.next
      }
      this.size--
      return removeNode.value
    }
  
    //remove from value
    removeValue(value) {
      if (this.isEmpty()) {
        return null;
      }
      if (this.head.value === value) {
        this.head = this.head.next;
        this.size--;
        return value;
      } else {
        let prev = this.head;
        while (prev.next && prev.next.value !== value) {
          prev = prev.next;
        }
        if (prev.next) {
          removedNode = prev.next;
          prev.next = removedNode.next;
          this.size--;
          return value;
        }
        return null;
      }
    }
    //Search
    search(value) {
      if (this.isEmpty()) {
        return -1;
      }
      let i = 0
      let curr = this.head
      while (curr) {
        if (curr.value === value) {
          return i
        }
        curr = curr.next
        i++
      }
      return -1
    }
  
    //Reverse
    reverse() {
      let prev = null;
      let curr = this.head;
      while (curr) {
        let next = curr.next;
        curr.next = prev;
        prev = curr;
        curr = next;
      }
      this.head = prev;
    }
    //Print the output
    print() {
      if (this.isEmpty()) {
        console.log("Linked List is Empty")
      }
      else {
        let curr = this.head
        let currValue = ''
        while (curr) {
          currValue += `${curr.value}->`
          curr = curr.next
        }
        console.log(currValue)
      }
    }
  }
  
  //Create a new node with LinkedList class
  const link = new linkedList()
  console.log("List is empty?=", link.isEmpty())
  
  //prepend : Add at start of the list
  link.prepend(50)
  link.prepend(10)
  link.prepend(20)
  link.prepend(30)
  
  // To print the output
  console.log(link.print())
  
  // //Apend: Add at end of the list
  link.append(5)
  link.append(1)
  link.append(2)
  link.append(3)
  
  // // Output after appneding
  console.log(link.print())
  
  link.insert(25, 2)
  console.log(link.print())
  
  link.remove(2)
  console.log(link.print())
  
  console.log(link.search(5))
  
  console.log(link.reverse())