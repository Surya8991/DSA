const LinkedList = require("./linked-list-tail")

class LinkedListStack {
  constructor() {
    this.list = new LinkedList()
  }
  push(value) {
    this.list.prepend(value)
  }
  pop() {
    this.list.removeFromFront()
  }
  isEmpty() {
    return this.list.isEmpty()
  }
  getSize() {
    return this.list.getSize()
  }
  peek() {
    return this.list.head.value
  }
  print() {
    return this.list.print()
  }
}

const q = new LinkedListStack()
console.log(q.isEmpty())
q.push(1)
q.push(2)
q.push(3)
q.push(4)
q.push(5)

console.log(q.print())
console.log(q.getSize())
q.pop()
console.log(q.print())
