class HashTable {
  constructor(size) {
    this.table = new Array(size)
    this.size = size
  }
  //hashing
  hash(key) {
    let total = 0
    for (let i = 0; i < key.length; i++) {
      total += key.charCodeAt(i)
    }
    return total % this.size
  }
  //set
  set(key, value) {
    let index = this.hash(key)
    let bucket = this.table[index]
    if (!bucket) {
      this.table[index] = [[key, value]]
    } else {
      const sameKeyItem = bucket.find(item => item[0] === key)
      if (sameKeyItem) {
        sameKeyItem[1] = value
      } else {
        bucket.push([key, value])
      }
    }
  }
  //get
  get(key) {
    let index = this.hash(key)
    let bucket = this.table[index]
    if (bucket) {
      const sameKeyItem = bucket.find(item => item[0] === key)
      if (sameKeyItem) {
        return sameKeyItem[1]
      }
    }
    return undefined
  }
  //remove
  remove(key) {
    let index = this.hash(key)
    let bucket = this.table[index]
    if (bucket) {
      const sameKeyItem = bucket.find(item => item[0] === key)
      if (sameKeyItem) {
        bucket.splice(bucket.indexOf(sameKeyItem), 1)
      }
    }
  }
  //display
  display() {
    for (let i = 0; i < this.table.length; i++) {
      if (this.table[i]) {
        console.log(i, this.table[i])
      }
    }
  }
}

//using hashTable
const hash = new HashTable(50)
hash.set("name", "surya")
hash.set("game", "pool")
hash.set("age", "20")
hash.display()
console.log("\n After adding mane key word which has same char code as name \n")
//After adding mane key word which has same char code as name
hash.set("mane", "Dummy")
hash.display()
console.log("Using get Method: ", hash.get("game"))
//removing mane key and its value
console.log("\n removing mane key and its value \n")
hash.remove("mane")
hash.display()