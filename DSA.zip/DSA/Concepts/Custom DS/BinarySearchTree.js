class Node {
    constructor(value) {
        this.value = value
        this.left = null
        this.right = null
    }
}

//Binary Search Tree
class BinarySearchTree {
    //Construct new tree node
    constructor() {
        this.root = null
    }
    //Check if the node is empty
    isEmpty() {
        return this.root === null
    }
    //Inserting a Node
    insert(value) {
        const newNode = new Node(value)
        if (this.isEmpty()) {
            this.root = newNode
        } else {
            this.insertNewNode(this.root, newNode)
        }
    }
    insertNewNode(root, newNode) {
        if (newNode.value < root.value) {
            if (root.left === null) {
                root.left = newNode
            } else {
                this.insertNewNode(root.left, newNode)
            }
        } else {
            if (root.right === null) {
                root.right = newNode
            } else {
                this.insertNewNode(root.right, newNode)
            }
        }
    }
    //Search

    search(root, value) {
        if (!root) {
            return false;
        }
        if (root.value === value) {
            return true;
        } else if (value < root.value) {
            return this.search(root.left, value);
        } else {
            return this.search(root.right, value);
        }
    }

    // DFS in PreOrder
    preOrder(root) {
        if (root) {
            console.log(root.value)
            this.preOrder(root.left)
            this.preOrder(root.right)
        }
    }
    //DFS in inOrder
    inOrder(root) {
        if (root) {
            this.inOrder(root.left)
            console.log(root.value)
            this.inOrder(root.right)
        }
    }
    //DFS in postOrder
    postOrder(root) {
        if (root) {
            this.postOrder(root.left)
            this.postOrder(root.right)
            console.log(root.value)
        }
    }
    //BFS levelOrder
    levelOrder() {
        let queue = []
        queue.push(this.root)
        while (queue.length) {
            let curr = queue.shift()
            console.log(curr.value)
            if (curr.left) {
                queue.push(curr.left)
            }
            if (curr.right) {
                queue.push(curr.right)
            }
        }
    }
    //Min and max
    min(root) {
        if (!root.left) {
            return root.value
        } else {
            return this.min(root.left)
        }
    }
    max(root) {
        if (!root.right) {
            return root.value
        } else {
            return this.min(root.right)
        }
    }

    //Delete method
    delete(value) {
        this.root = this.deleteNode(this.root, value);
    }

    deleteNode(root, value) {
        if (root === null) {
            return root;
        }
        if (value < root.value) {
            root.left = this.deleteNode(root.left, value);
        } else if (value > root.value) {
            root.right = this.deleteNode(root.right, value);
        } else {
            if (!root.left && !root.right) {
                return null;
            }
            if (!root.left) {
                return root.right;
            } else if (!root.right) {
                return root.left;
            }
            root.value = this.min(root.right);
            root.right = this.deleteNode(root.right, root.value);
        }
        return root;
    }
}

//Implementing
const bst = new BinarySearchTree()
console.log(bst.isEmpty())
bst.insert(10)
bst.insert(5)
bst.insert(15)
bst.insert(3)
bst.insert(7)
console.log(" \n Using Search Method \n")
console.log(bst.search(bst.root,50))
console.log(bst.search(bst.root,10))
console.log(" \n Using preOrder Method \n")
bst.preOrder(bst.root)
console.log(" \n Using inOrder Method \n")
bst.inOrder(bst.root)
console.log(" \n Using postOrder Method \n")
bst.postOrder(bst.root)
console.log(" \n Using levelOrder Method \n")
bst.levelOrder()
console.log("\n Using min and max method")
console.log("Min Node: ",bst.min(bst.root))
console.log("Max Node: ",bst.max(bst.root))
console.log("\n Using delete method")
bst.delete(7)
bst.levelOrder()