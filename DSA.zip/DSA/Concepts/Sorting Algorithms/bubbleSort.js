function bubbleSort(arr){
    
    let swapped;
       do {
           swapped = false
            for(let i = 0; i < arr.length; i++){
                let temporary= arr[i]
                if(arr[i] > arr[i + 1]){
                    arr[i] = arr[i + 1]
                    arr[i + 1 ] = temporary
                  swapped = true
                    
                } 
            }
        }while(swapped)
        return arr
    }
    console.log("Sorted Array = "+ bubbleSort([-2, -4, 9 , 2,9, -19, 4]))
    // Output
    //Sorted Array = -19,-4,-2,2,4,9,9