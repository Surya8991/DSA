const map = new Map([['a', 1], ['b', 2]])
console.log("\n To display map");
console.log(map)

//To loop map
console.log("\n To Loop the map elements");
for (const [key, value] of map) {
  console.log(`${key}:${value * 3}`)
}

// to add element in map
console.log("\n To add map elements");
map.set(['c', 3]);
console.log(map)

//To know the size of map
console.log("\n To know the size of map elements");
console.log(map.size)

// to delete all element
console.log("\n To clear all map elements");
map.clear();
console.log(map)
