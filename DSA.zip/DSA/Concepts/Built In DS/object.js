//Objects
let student={
    'name':"Surya",
    "age":24,
    "hobbies":"Reading Books, Movies"
  }
  console.log(student)
  //Adding new values using Bracket method in Objects
  student["Degree"]="Engineering"
  console.log("After Adding Degree Value Bracket Notation \n",student)
  //Adding new values using Dot method in Objects
  student.skills="Design"
  console.log("After Adding Skills Value Dot Notation \n",student)
  //Printing certain Key using Dot and Bracket Notation
  console.log("Bracket Notation: ",student["name"])
  console.log("Dot Notation: ",student.skills)
  delete student["hobbies"] //Bracket Notation
  console.log("After Deleting",student)
  delete student.skills //Bracket Notation
  console.log("After Deleting",student)
  //Using Stringify
  console.log("Stringify",JSON.stringify(student))