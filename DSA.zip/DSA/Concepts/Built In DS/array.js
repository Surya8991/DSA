//Arrays
let arr=[1,2,3]
//To insert and remove an value
arr.push(4)
console.log("Adding Element at end using push:",arr)
arr.pop()
console.log("Removing Element at end using push:",arr)
arr.unshift(0)
console.log("Adding Element at end using push:",arr)
arr.shift()
console.log("Removing Element at end using push:",arr)
console.log("Length of the array",arr.length)
//Changing Value at a position
arr[2]=34
console.log("After changing the value",arr)
//Index
console.log("The index of value 1 in array",arr.indexOf(1))
//Sorting
arr=[12,5,9,8,7,69,1]
console.log("After Sorting in Ascending Order= "+arr.sort())
console.log("After Sorting in Descending Order= "+arr.sort((a,b)=>b-a))
//Deleting
delete arr[0]
console.log("After Deleting = "+arr)