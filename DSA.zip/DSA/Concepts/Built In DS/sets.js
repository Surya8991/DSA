//Built In Data Structure are Arrays,Objects,Sets and Maps
//Set
const set = new Set([1,2,3]);
//To view Set
console.log(set)
// to loop the set elements
console.log("\n The power of sets are:");
for(item of set)
  {
    console.log(item**2);
  }

//To add elemts in set
console.log("\n To add elemts in set:");
set.add(4)
console.log(set)

console.log("\n To check if the elemnet is present");
console.log(set.has(2.0))
console.log(set.has(2))
console.log(set.has(02))
console.log(set.has(20))

console.log("\n To delete an element from set")
set.delete(4)
console.log(set)

console.log("\n To check the size")
console.log(set.size)

console.log("\n to clear the set")
set.clear()
console.log(set)