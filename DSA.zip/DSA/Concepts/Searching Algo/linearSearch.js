function linearSearch(arr,key)
{
    for(let i=0;i<arr.length;i++)
    {
        if(arr[i]==key)
        {
            return i;
        }
    }
    return -1
}
console.log("The Position of the key is "+linearSearch([12,56,778,7],7))